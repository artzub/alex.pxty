package threads;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;

/**
 * Created with IntelliJ IDEA.
 * User: Фёдор
 * Date: 10.04.13
 * Time: 22:36
 * To change this template use File | Settings | File Templates.
 */
public class main {
    public static void main(String[] args) throws IOException {
        Path p = Paths.get("C:\\Folder");
        CheckDirs cd = new CheckDirs();
        Files.walkFileTree(p, cd);
        //System.out.println(p.toString());
        //System.out.println(Files.size(p));
    }
}
