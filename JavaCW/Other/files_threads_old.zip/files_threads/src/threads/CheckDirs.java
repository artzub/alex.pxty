package threads;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;

import static java.nio.file.FileVisitResult.*;

/**
 * Created with IntelliJ IDEA.
 * User: Фёдор
 * Date: 10.04.13
 * Time: 23:18
 * To change this template use File | Settings | File Templates.
 */
public class CheckDirs extends SimpleFileVisitor<Path> {

    @Override
    public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
        //System.out.format("Directory: %s%n", dir);
        //dir.
        if(exc != null){
            System.out.println(exc.getMessage());
        }
        return CONTINUE;
    }

    @Override
    public FileVisitResult visitFile(Path file, BasicFileAttributes attr) throws IOException {
        /*
        if (attr.isSymbolicLink()) {
            System.out.format("Symbolic link: %s ", file);
        } else if (attr.isRegularFile()) {
            System.out.format("Regular file: %s ", file);
        } else {
            System.out.format("Other: %s ", file);
        }
        */
        long overallSize = 0;
        if(attr.isRegularFile()){
            overallSize += attr.size()/1024;
        }
        System.out.println("(" + attr.size() + "bytes)");
        return CONTINUE;
    }
}
