package ServletClasses;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class LoginServlet extends HttpServlet {

    public static Boolean isActiveSession = false;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //HttpSession session = req.getSession();
        //Boolean isActiveSession = (Boolean)session.getAttribute("currentSession");
        if(isActiveSession == false) {
            String _login = req.getParameter("login");
            String _pass = req.getParameter("pass");

            if(_login.equals(_pass) && !_login.isEmpty() && !_pass.isEmpty()) {
                isActiveSession = true;
                HttpSession session = req.getSession();
                session.setAttribute("currentSession", isActiveSession);
            }
        }
        resp.sendRedirect("index.jsp");
    }
}
