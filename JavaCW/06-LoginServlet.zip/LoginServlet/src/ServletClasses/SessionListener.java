package ServletClasses;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/*
 Q. If one user close the browse abruptly, the browser's session should be destroyed,
 but it is not destroying automatically.
 A. You need to understand that the session is maintained on the server.
So when the browser is closed, the server is not informed - and hence it continues to maintain the session on the server for a specified amount of time.
(i.e. whatever the session-timeout interval configured in web.xml which is 30 minutes by default).
So when the client doesn't visit the application anymore for over 30 minutes, then the session will get destroyed on the server.
If one user close the browse abruptly, the browser's session should be destroyed, but it is not destroying automatically.
How does this affect your application?
If the user opens a new browser and returns to your site, he will get a new session started on the server - not the old one.
Unless you can explain a specific need to invalidate sessions when the browser is closed, this should be fine for your application.
Are you doing any specific logic in the sessionDestroyed() ?
*/

@WebListener() //пометка, что это слушальщик сессий
public class SessionListener implements HttpSessionListener {

    public int _sessionsCounter = 0;

    @Override
    public void sessionCreated(HttpSessionEvent httpSessionEvent) {
        _sessionsCounter++;
        System.out.println("Session Created: " + httpSessionEvent.getSession().getId());
        System.out.println("Total Sessions: " + _sessionsCounter);
    }

    @Override
    public void sessionDestroyed(HttpSessionEvent httpSessionEvent) {
        _sessionsCounter--;
        System.out.println("Session Destroyed: " + httpSessionEvent.getSession().getId());
        System.out.println("Total Sessions: " + _sessionsCounter);
    }
}
