package auction;

import java.math.BigDecimal;

/**
 * Created with IntelliJ IDEA.
 * Admin: stud
 * Date: 28.03.13
 * Time: 19:55
 * To change this template use File | Settings | File Templates.
 */
public class Main {

    /*
       Bid(user, price)
       ProductInfo(initPrice, _bids)
       _bids(bid)
       _products(product, initPrice)
       _placedBids(product, ProductInfo)
    */

    public static void main(String[] args) {
        Admin user = new Admin();
        user.placeProduct("laptop", new BigDecimal("154.30"));
        user.addBid("Ivan", "laptop", new BigDecimal("170.40"));
        user.addBid("Andrey", "laptop", new BigDecimal("165.50"));
        user.addBid("Fedor", "laptop", new BigDecimal("183.75"));
        user.sellProduct("laptop");
    }

}
