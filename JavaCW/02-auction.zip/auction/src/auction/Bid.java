package auction;

import java.math.BigDecimal;
import java.util.HashSet;

/**
 * Created with IntelliJ IDEA.
 * Admin: stud
 * Date: 28.03.13
 * Time: 19:31
 * To change this template use File | Settings | File Templates.
 */
public class Bid {

    public Bid(String user, BigDecimal price) {
        this._user = user;
        this._price = price;
    }

    String _user;
    BigDecimal _price;
}
