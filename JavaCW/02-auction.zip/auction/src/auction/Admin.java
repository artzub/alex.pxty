package auction;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

public class Admin implements Auction {
    Map<String, BigDecimal> _products = new HashMap<String, BigDecimal>();
    Map<String, ProductInfo> _placedBids = new HashMap<String, ProductInfo>();

    @Override
    public void placeProduct(String product, BigDecimal initialPrice) {
        _products.put(product, initialPrice);
    }

    @Override
    public void addBid(String user, String product, BigDecimal price) {
        BigDecimal bd = _products.get(product);
        if(bd == null) {
            System.out.println("No such product!");
            return;
        }
        Bid bid = new Bid(user, price);
        if(!_placedBids.containsKey(product)){
            System.out.println("User " + user + " placed the first bid!");
            ProductInfo pi = new ProductInfo(bd, bid);
            _placedBids.put(product, pi);
        }
        else {
            ProductInfo pi = _placedBids.get(product);
            pi._bids.add(bid);
            Collections.sort(pi._bids, new Comparator<Bid>() {
                @Override
                public int compare(Bid o1, Bid o2) {
                    return o1._price.compareTo(o2._price) == -1 ? 1 : -1;
                }
            });
        }
    }

    @Override
    public void removeBid(String user, String product) {
        ProductInfo pi = _placedBids.get(product);
        if(pi == null){
            System.out.println("No such product!");
            return;
        }
        Bid bid = null;
        for(Bid b : pi._bids){
            if(b._user == user){
                bid = b;
            }
        }
        if(bid != null) {
            pi._bids.remove(bid);
        }
        else {
            System.out.println("No such user!");
            return;
        }
    }

    @Override
    public boolean sellProduct(String product) {
        ProductInfo pi = _placedBids.get(product);
        if(pi != null) {
            Bid bid = pi._bids.get(0);
            System.out.println(product + " was sold to " + bid._user + " at price " + bid._price.toString());
            return true;
        }
        return false;
    }
}
