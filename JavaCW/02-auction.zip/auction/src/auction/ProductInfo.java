package auction;

import java.math.BigDecimal;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * Admin: stud
 * Date: 28.03.13
 * Time: 19:27
 * To change this template use File | Settings | File Templates.
 */
public class ProductInfo {
    BigDecimal _initialPrice;
    List<Bid> _bids = new LinkedList<Bid>();

    public ProductInfo(BigDecimal initialPrice, Bid bid) {
        this._initialPrice = initialPrice;
        this._bids.add(bid);
    }
}
