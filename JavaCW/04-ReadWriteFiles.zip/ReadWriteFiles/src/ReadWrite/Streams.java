package ReadWrite;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Фёдор
 * Date: 05.05.13
 * Time: 19:59
 * To change this template use File | Settings | File Templates.
 */
public class Streams {
    public static void main(String[] args) throws java.io.IOException {

        List lst = new ArrayList();
        final int vol = 64;
        int remainder;

        try (InputStream ips = new FileInputStream("c:/tmpDir/ufat.dll")) {
            byte[] bArray = new byte[vol];
            remainder = ips.available() % vol;
            while((ips.read(bArray)) != -1) {
                for(byte b : bArray){
                    lst.add(b);
                }
            }
        }

        for(int i = vol - remainder; i > 0; --i) lst.remove(lst.size() - 1);

        try (OutputStream ops = new FileOutputStream("c:/tmpDir/ufat1.dll")) {
            for(Object obj : lst) {
                ops.write((byte)obj);
            }
        }

        //readline returns a String containing the contents of the line,
        //not including any line-termination characters =>
        //using '\r' + '\n' to return windows lines
        try (BufferedReader rdr = new BufferedReader(
                new InputStreamReader(
                        new FileInputStream("c:/tmpDir/msys.bat"), "Windows-1251"))) {
            try(BufferedWriter rtr = new BufferedWriter(
                    new OutputStreamWriter(
                            new FileOutputStream("c:/tmpDir/msys1.bat"), "Windows-1251"))) {
                String str;
                while ((str = rdr.readLine()) != null) {
                    rtr.write(str + '\r' + '\n');
                }
            }
        }
    }
}
