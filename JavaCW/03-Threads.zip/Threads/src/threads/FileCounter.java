package threads;

import java.io.File;

/**
 * Created with IntelliJ IDEA.
 * User: Фёдор
 * Date: 22.06.13
 * Time: 16:21
 * To change this template use File | Settings | File Templates.
 */

public class FileCounter {

    private static int _files, _folders;

    private void countFiles(File file) {
        for (File child : file.listFiles()) {
            if (child.isFile()) {
                ++_files;
            } else {
                ++_folders;
                countFiles(child);
            }
        }
    }

    public static void main(String[] args) {
        FileCounter fc = new FileCounter();
        fc.countFiles(new File("c:/msys"));
        System.out.println("Files in the directory: " + _files);
        System.out.println("Folders in the directory: " + _folders);
    }
}
