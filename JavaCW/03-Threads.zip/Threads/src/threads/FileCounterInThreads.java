package threads;

import java.io.File;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created with IntelliJ IDEA.
 * User: Фёдор
 * Date: 22.06.13
 * Time: 16:36
 * To change this template use File | Settings | File Templates.
 */

public class FileCounterInThreads {

    //вводим atomic-переменные, чтобы достичь атомарности
    //операций инкрементирования и снизить риск race error
    private static AtomicInteger _files = new AtomicInteger(0);
    private static AtomicInteger _folders = new AtomicInteger(0);
    private static AtomicInteger _threads = new AtomicInteger(0);

    public static void main(String[] args) throws InterruptedException {
        FileCounterInThreads fct = new FileCounterInThreads();
        fct.countFilesInThreads(new File("c:/msys"));
        //текущий поток должен жить до тех пор, пока подсчет не завершится
        //теоретически _threads может стать отрицательным
        while (_threads.get() > 0) {
            Thread.sleep(100);
        }
        System.out.println("Files in the directory: " + _files.get());
        System.out.println("Folders in the directory: " + _folders.get());
    }

    private void countFilesInThreads(File file) {
        for (final File child : file.listFiles()) {
            if (child.isFile()) {
                _files.incrementAndGet();
            } else {
                _threads.incrementAndGet();
                new Thread(new Runnable() {
                    public void run() {
                        _folders.incrementAndGet();
                        countFilesInThreads(child);
                        _threads.decrementAndGet();
                    }
                }).start();
            }
        }
    }
}
