package threads;

import java.io.File;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created with IntelliJ IDEA.
 * User: Фёдор
 * Date: 22.06.13
 * Time: 16:58
 * To change this template use File | Settings | File Templates.
 */
public class FileCounterInThreadPool {

    //ThreadPool решает 2 важные задачи:
    // 1)улучшенная производительность путем управления оптимальным кол-вом потоков
    // 2)является эффективной "обёрткой" для многопоточных задач с набором полезных свойств
    private static ThreadPoolExecutor executor = new ScheduledThreadPoolExecutor(10);
    private static AtomicInteger _files = new AtomicInteger(0);
    private static AtomicInteger _folders = new AtomicInteger(0);
    private static AtomicInteger _threads = new AtomicInteger(0);

    public static void main(String[] args) throws InterruptedException {
        FileCounterInThreadPool fctp = new FileCounterInThreadPool();
        fctp.countFilesInThreadPool(new File("c:/msys"));
        while (_threads.get() > 0) {
            Thread.sleep(100);
        }
        System.out.println("Total file number: " + _files.get());
        System.out.println("Folders in the directory: " + _folders.get());
    }

    private void countFilesInThreadPool(File file) {
        for (final File child : file.listFiles()) {
            if (child.isFile()) {
                _files.incrementAndGet();
            } else {
                _threads.incrementAndGet();
                executor.execute(new Runnable() {
                    public void run() {
                        _folders.incrementAndGet();
                        countFilesInThreadPool(child);
                        _threads.decrementAndGet();
                    }
                });
            }
        }
    }
}
