package CurrencyClasses;

public class Main
{
    public static void main(String[] args) throws Exception
    {
        Currency cur0 = new Currency(48.788, Currency.CurType.USD);
        Currency cur1 = new Currency("21.212", Currency.CurType.USD);
        Currency cur2 = new Currency(30, Currency.CurType.USD);
        Currency cur3 = new Currency(20.001, Currency.CurType.USD);

        cur0.add(cur1);
        cur0.add(cur2);
        cur0.subtract(cur3);

        System.out.println(cur0.get_decim());
    }
}
