package CurrencyClasses;

import java.math.BigDecimal;

public class Currency
{
    public enum CurType {RUR, EUR, USD};

    private BigDecimal _decim;
    private CurType _curType;
    final int _ROUND = 2;

    public BigDecimal get_decim() {
        return _decim;
    }

    private void setConstructor(BigDecimal bd, CurType c)
    {
        if(bd.scale() != _ROUND)
            bd = bd.setScale(_ROUND, BigDecimal.ROUND_HALF_EVEN);
        this._decim = bd;
        this._curType = c;
    }

    //CONSTRUCTORS//
    public Currency(BigDecimal bd, CurType c)
    {
        this.setConstructor(bd, c);
    }

    public Currency(double d, CurType c)
    {
        this.setConstructor(new BigDecimal(d), c);
    }

    public Currency(int i, CurType c)
    {
        this.setConstructor(new BigDecimal(i), c);
    }

    public Currency(String s, CurType c)
    {
        this.setConstructor(new BigDecimal(s), c);
    }

    //LOGIC//
    private BigDecimal setScale(BigDecimal bd)
    {
        if(bd.scale() != _ROUND)
            bd = bd.setScale(_ROUND, BigDecimal.ROUND_HALF_EVEN);

        return  bd;
    }

    private boolean hasSameCurType(Currency cur) //throws Exception
    {
        if(this._curType != cur._curType)
            return false;
            //throw new Exception("__Error__: Types of currencies do not coincide !");

        return true;
    }

    //CALCULUS//
    public void add(Currency cur)
    {
        if(hasSameCurType(cur)) {
            this._decim = this._decim.add(cur._decim);
        }
    }

    public void subtract(Currency cur)
    {
        if(hasSameCurType(cur))
            this._decim = this._decim.subtract(cur._decim);
    }

    public void multiply(Currency cur)
    {
        if(hasSameCurType(cur))
            this._decim = this._decim.multiply(cur._decim);
    }

    public void divide(Currency cur)
    {
        if(hasSameCurType(cur))
            this._decim = this._decim.divide(cur._decim);
    }
}
